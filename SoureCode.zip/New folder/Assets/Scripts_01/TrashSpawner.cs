using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrashSpawner : MonoBehaviour
{
    [SerializeField] private GameObject[] smallSpawner;
    [SerializeField] private GameObject[] mediumSpawner;
    [SerializeField] private GameObject[] largeSpawner;
    [SerializeField] private GameObject[] o2Spawner;

    [SerializeField] private float smallInterval = 1f;
    [SerializeField] private float mediumInterval = 2f;
    [SerializeField] private float largeInterval = 3f;
    [SerializeField] private float timespawn = 3f;
    
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(spawnTrash(smallInterval, smallSpawner));
        StartCoroutine(spawnTrash(mediumInterval, mediumSpawner));
        StartCoroutine(spawnTrash(largeInterval, largeSpawner));
        StartCoroutine(spawnTrash(timespawn, o2Spawner));
    }

    private IEnumerator spawnTrash(float interval, GameObject[] trash)
    {
        yield return new WaitForSeconds(interval);
        int random = Random.Range(0, trash.Length);
        Instantiate(trash[random],new Vector3(Random.Range(-44f,47),-1f,0),Quaternion.identity);
        StartCoroutine(spawnTrash(interval, trash));
    }
}
