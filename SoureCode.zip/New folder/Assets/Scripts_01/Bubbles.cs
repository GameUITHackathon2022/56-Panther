using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bubbles : MonoBehaviour
{
    Animator m_ani;
    private void Awake()
    {
    }
    public void onEnableBubbles()
    {
        gameObject.SetActive(true);
        m_ani.SetTrigger("run");
        StartCoroutine(timeUnEnable());
    }
    private IEnumerator timeUnEnable()
    {
        yield return new WaitForSeconds(1f);
        gameObject.SetActive(false);
    }
}
