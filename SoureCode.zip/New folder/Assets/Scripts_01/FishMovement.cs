using System.Collections;
using System.Collections.Generic;

using UnityEngine;

public class FishMovement : MonoBehaviour
{
    Rigidbody2D rb;

    public float xSpeed = 5f;
    public float minYspeed = 1f;
    bool m_move;
    // Start is called before the first frame update
    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    void Start()
    {
        randomMove();
    }

    // Update is called once per frame
    void Update()
    {
        rb.velocity = m_move ? new Vector2(-xSpeed, minYspeed)
            : new Vector2(xSpeed, minYspeed);
        Flip();
    }
    public void randomMove()
    {
        m_move = transform.position.x > 0 ? true : false;

    }
    void Flip()
    {
        if (m_move)
        {
            if (transform.position.x < 0) return;
            transform.localScale = new Vector3(transform.localScale.x * -1, transform.localScale.y, transform.localScale.z);
        }
        else
        {
            if (transform.position.x > 0) return;
            transform.localScale = new Vector3(transform.localScale.x * -1, transform.localScale.y, transform.localScale.z);
        }
    }
}
