using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class FishSpawner : MonoBehaviour
{
    public GameObject[] fishPrelabs;

    public float spawnTime;
    bool m_isGameOver;
    void Start()
    {
        StartCoroutine(GameSpawn());
    }
    IEnumerator GameSpawn()
    {
        while(!m_isGameOver)
        {
            SpawnFish();
            yield return new WaitForSeconds(spawnTime);
        }
    }
    void SpawnFish()
    {
        Vector3 spawnPos = Vector3.zero;
        float randCheck = Random.Range(0f, 1f);
        if (randCheck >= 0.5f)
        {
            spawnPos = new Vector3(12, Random.Range(4f, -6f), 0);
        }
        else
        {
            spawnPos = new Vector3(-12, Random.Range(4f, -6f), 0);
        }

        if (fishPrelabs != null && fishPrelabs.Length > 0)
        {
            int randIdx = Random.Range(0, fishPrelabs.Length);

            if (fishPrelabs[randIdx] != null)
            {
                GameObject fishClone = Instantiate(fishPrelabs[randIdx], spawnPos, Quaternion.identity);
            }
        }
    }
}
