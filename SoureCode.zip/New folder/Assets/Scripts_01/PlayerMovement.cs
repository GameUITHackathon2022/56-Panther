using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public enum state
{
    idle,
    walking
}
public class PlayerMovement : MonoBehaviour
{
    public state currentPlayer;
    public GameObject text;
    Rigidbody2D m_rb;
    Animator m_ani;
    Vector2 direction;
    public Slider slider;
    int value;
    public bool checkstartgame = false;
    [SerializeField] private GameObject effectbubbles;
    [SerializeField] private float speedMove = 3f;
    [SerializeField] private float speedDown = 50f;

    // Start is called before the first frame update
    void Awake()
    {
        m_rb = GetComponent<Rigidbody2D>();
        m_ani = GetComponent<Animator>();
        
        currentPlayer = state.idle;
    }


    // Update is called once per frame
    void FixedUpdate()
    {
        if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
        {
            checkstartgame = true;
            text.SetActive(false);
            effectbubbles.SetActive(true);
        }
        if (!checkstartgame)
        {
            return;
        }
        direction = Vector2.zero;
        float hori = Input.GetAxisRaw("Horizontal");
        float verti = Input.GetAxisRaw("Vertical");
        direction = new Vector2(hori, verti);
        direction = direction.normalized;
        
        if (direction != Vector2.zero)
        {
            m_ani.SetBool("walking", true);
            m_ani.SetFloat("moveX", direction.x);
            m_ani.SetFloat("moveY", direction.y);
            Movement();
            currentPlayer = state.walking;
        }
        else
        {
            m_ani.SetBool("walking", false);
            currentPlayer = state.idle;
        }
        if (currentPlayer == state.idle)
        {
            m_rb.velocity = Vector2.down * speedDown * Time.deltaTime ;
        }
    }
    private void Movement()
    {
        m_rb.MovePosition(m_rb.position + direction * speedMove * Time.deltaTime);
    }
    private void OnTriggerEnter2D(Collider2D col)
    {
        if(col.CompareTag("linestop"))
        {
            effectbubbles.SetActive(false);
        }
        if(col.CompareTag("small"))
        {
            Debug.Log("cham small");
             Destroy(col.gameObject);
        }
        
    }
    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.CompareTag("linestop"))
        {
            effectbubbles.SetActive(true);
        }
    }
    public void isStartGame()
    {
        checkstartgame = true;
    }

}
