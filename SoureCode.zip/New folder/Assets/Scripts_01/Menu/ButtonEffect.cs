using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonEffect : MonoBehaviour
{
    
    public GameObject c_Help;
    public GameObject c_Settings;
    public GameObject c_Menu;
    PlayerMovement m_player;
    private void Awake()
    {
        m_player = GetComponent<PlayerMovement>();
    }

    private void Update()
    {
      
    }
    public void showSettings()
    {
        c_Settings.SetActive(true);
        c_Menu.SetActive(false);
    }
    public void showHelp()
    {
        c_Help.SetActive(true);
        c_Menu.SetActive(false);
    }
    public void returnMenu()
    {
        c_Help.SetActive(false);
        c_Menu.SetActive(true);
        c_Settings.SetActive(false);
    }
   
    public void endGame()
    {
        Application.Quit();
    }
    public void startGame()
    {
        SceneManager.LoadScene("GamePlay");
    }
}
