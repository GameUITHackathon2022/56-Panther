using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MusicPlay : MonoBehaviour
{
    public AudioSource audioSource;
    private float MusicVolume = (float)0.3;

    public Slider volumeSlider;
    // Start is called before the first frame update
    public void Start()
    {
        audioSource.Play();
    }

    // Update is called once per frame
    private void Update()
    {
        getvalVolume();
        setvalVolume();
        //audioSource.volume = MusicVolume;
        //PlayerPrefs.SetFloat("volume", MusicVolume);
        //audioSource.volume = MusicVolume;
        //MusicVolume = PlayerPrefs.GetFloat("volume");
        //MusicVolume = volumeSlider.value;
    }

    public void getvalVolume()
    {
        MusicVolume = volumeSlider.value;
    }
    public void setvalVolume()
    {
        audioSource.volume = MusicVolume;
    }
}
