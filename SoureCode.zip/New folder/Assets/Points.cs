using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Points : MonoBehaviour
{
    private int count = 0;
    public Text itemsText;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("trash"))
        {
            Destroy(collision.gameObject);
            count++;
            itemsText.text = "Points: " + count;
        }
    }
}

